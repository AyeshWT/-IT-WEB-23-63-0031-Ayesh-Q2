﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace StudentManagement.Models
{
    public class Course
    {
        public int CourseID { get; set; }

        [Required]
        [StringLength(100)]
        public string CourseName { get; set; }

        [StringLength(255)]
        public string CourseDescription { get; set; }

        public ICollection<Student> Students { get; set; }
    }
}
